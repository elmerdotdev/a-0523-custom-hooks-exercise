const Quote = () => {
  return (
    <blockquote>
      “Happiness can be found, even in the darkest of times, if one only remembers to turn on the light.” — Steven Kloves
    </blockquote>
  )
}

export default Quote