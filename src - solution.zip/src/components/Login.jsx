import { useState } from 'react'

import './Login.css'

const Login = (props) => {
  const [fullname, setFullname] = useState('')

  const handleSubmit = (event) => {
    event.preventDefault()

    props.setStorage({ name: fullname })
  }

  return (
    <div className="wrapper__login">
      <form onSubmit={handleSubmit}>
          <h2>Hi. What&apos;s your name?</h2>
          <div className="wrapper__login_input">
            <input type="text" name="fullname" required autoComplete='off' onChange={(e) => setFullname(e.target.value)} />
            <button type="submit">Login</button>
          </div>
      </form>
    </div>
  )
}

export default Login