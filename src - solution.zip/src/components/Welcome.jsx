import './Welcome.css'

const Welcome = (props) => {
  return (
    <div className="wrapper__welcome">
      <h2>Welcome {props.fullname}!</h2>
      <button onClick={() => props.setStorage({ name: '' })}>Log out</button>
    </div>
  )
}

export default Welcome