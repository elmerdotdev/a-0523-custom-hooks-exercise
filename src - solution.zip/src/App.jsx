import { useEffect } from "react";
import './App.css'
import useLocalStorage from "./hooks/useLocalStorage";

import Login from "./components/Login";
import Welcome from "./components/Welcome";
import Quote from "./components/Quote";

const App = () => {
  const [storage, setStorage] = useLocalStorage('login', { name: '' });

  useEffect(() => {
    console.log(storage)
    console.log(typeof(storage))
  }, [storage])

  return (
    <div className="wrapper">
      {storage.name == '' ? (
        <Login setStorage={setStorage} />
      ) : (
        <Welcome fullname={storage.name} setStorage={setStorage} />
      )}
      <Quote />
    </div>
  )
}

export default App